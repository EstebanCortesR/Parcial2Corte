const openDialogButton = document.getElementById('openDialogButton');
const closeDialogButton = document.getElementById('closeDialogButton');
const dialog = document.getElementById('popup');
const frameContainer = document.getElementById('frameContainer');

openDialogButton.addEventListener('click', () => {
    dialog.showModal();
    frameContainer.innerHTML = '';
    frameContainer.appendChild(document.getElementById('frame1').contentDocument.body.cloneNode(true));
});

closeDialogButton.addEventListener('click', () => {
    dialog.close();
});
